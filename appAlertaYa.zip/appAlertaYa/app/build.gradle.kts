plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
}

android {
    namespace = "com.example.appalertaya"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.example.appalertaya"
        minSdk = 24
        targetSdk = 36
        versionCode = 1
        versionName = "1.0"
        multiDexEnabled = true

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            isShrinkResources = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    kotlinOptions {
        jvmTarget = "1.8"
    }

    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
            excludes += "META-INF/DEPENDENCIES"
            excludes += "META-INF/INDEX.LIST"
            excludes += "META-INF/LICENSE"
            excludes += "META-INF/LICENSE.txt"
            excludes += "META-INF/NOTICE"
            excludes += "META-INF/NOTICE.txt"
        }
    }
}

// 🔹 FORZAR versión específica de Guava para TODAS las dependencias
configurations.all {
    resolutionStrategy {
        // Forzar Guava 30.1 que es la más estable
        force("com.google.guava:guava:30.1-android")
        force("com.google.guava:listenablefuture:9999.0-empty-to-avoid-conflict-with-guava")

        // Evitar actualizaciones automáticas problemáticas
        eachDependency {
            if (requested.group == "com.google.guava" && requested.name == "guava") {
                useVersion("30.1-android")
                because("Soluciona ClassFormatError en AbstractBiMap")
            }
        }
    }
}

dependencies {
    // AndroidX
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.activity)
    implementation(libs.androidx.constraintlayout)
    implementation("com.squareup.okhttp3:okhttp:4.12.0")


    // Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.7.3")

    // Activity KTX
    implementation("androidx.activity:activity-ktx:1.8.2")

    // Material Design
    implementation("com.google.android.material:material:1.11.0")

    // 🔹 Guava - versión compatible
    implementation("com.google.guava:guava:30.1-android")

    // Google Maps & Location - EXCLUYENDO Guava
    implementation("com.google.android.gms:play-services-maps:18.1.0") {
        exclude(group = "com.google.guava")
    }
    implementation("com.google.android.gms:play-services-location:21.0.1") {
        exclude(group = "com.google.guava")
    }

    implementation("com.google.android.material:material:1.11.0")
    // Glide para imágenes
    implementation("com.github.bumptech.glide:glide:4.16.0")
    // Coordinator Layout
    implementation("androidx.coordinatorlayout:coordinatorlayout:1.2.0")

    // Networking & Utils
    implementation("com.squareup.okhttp3:okhttp:4.11.0")
    implementation("com.github.bumptech.glide:glide:4.15.1")

    // Alertas
    implementation("com.github.f0ris.sweetalert:library:1.6.2") {
        exclude(group = "com.google.guava")
    }
    implementation(libs.volley)

    // Tests
    testImplementation(libs.junit)
    androidTestImplementation(libs.androidx.junit)
    androidTestImplementation(libs.androidx.espresso.core)
}