package com.example.appalertaya

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import okhttp3.*
import org.json.JSONObject
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private val client = OkHttpClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val edtUsuario = findViewById<EditText>(R.id.edtUsuario)
        val edtContrasena = findViewById<EditText>(R.id.edtContrasena)
        val btnLogin = findViewById<Button>(R.id.btnLogin)
        val btnRegistro = findViewById<Button>(R.id.btnRegister)
        val txtRecuperarContrasena = findViewById<TextView>(R.id.txtRecuperarContrasena)

        // ✅ Si ya hay sesión guardada, saltar directamente al menú
        val prefs = getSharedPreferences("UserSession", Context.MODE_PRIVATE)
        val userId = prefs.getInt("user_id", -1)
        if (userId != -1) {
            startActivity(Intent(this, MenuActivity::class.java))
            finish()
            return
        }

        // --- 🔐 Botón Iniciar Sesión ---
        btnLogin.setOnClickListener {
            val correo = edtUsuario.text.toString().trim()
            val contrasena = edtContrasena.text.toString().trim()

            when {
                correo.isEmpty() -> mostrarToastError("Por favor ingresa tu correo")
                contrasena.isEmpty() -> mostrarToastError("Por favor ingresa tu contraseña")
                else -> iniciarSesion(correo, contrasena)
            }
        }

        // --- 🧩 Botón Ir a Registro ---
        btnRegistro.setOnClickListener {
            startActivity(Intent(this, RegistroActivity::class.java))
        }

        // --- 🔑 Enlace Recuperar Contraseña ---
        txtRecuperarContrasena.setOnClickListener {
            mostrarDialogoRecuperarContrasena()
        }
    }

    // --- 🚀 FUNCIÓN PARA INICIAR SESIÓN CON API ---
    private fun iniciarSesion(correo: String, contrasena: String) {
        val url = "https://www.inkadroid.com/alertaya/api/login_user.php"

        val formBody = FormBody.Builder()
            .add("correo", correo)
            .add("contrasena", contrasena)
            .build()

        val request = Request.Builder()
            .url(url)
            .post(formBody)
            .build()

        client.newCall(request).enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                runOnUiThread { mostrarToastError("Error de conexión con el servidor") }
            }

            override fun onResponse(call: Call, response: Response) {
                val responseData = response.body?.string()
                runOnUiThread {
                    try {
                        val json = JSONObject(responseData ?: "")
                        val status = json.getString("status")
                        val message = json.getString("message")

                        if (status == "success") {
                            val user = json.getJSONObject("user")
                            val userId = user.getInt("id")
                            val nombre = user.getString("nombre")
                            val correo = user.getString("correo")
                            val telefono = user.optString("telefono", "")

                            // ✅ Guardar todos los datos en SharedPreferences
                            val prefs = getSharedPreferences("UserSession", Context.MODE_PRIVATE)
                            prefs.edit()
                                .putInt("user_id", userId)
                                .putString("nombre", nombre)
                                .putString("correo", correo)
                                .putString("telefono", telefono)
                                .apply()

                            mostrarDialogoBienvenida(nombre)
                        } else {
                            mostrarToastError(message)
                        }
                    } catch (e: Exception) {
                        mostrarToastError("Respuesta inválida del servidor")
                    }
                }
            }
        })
    }

    // 🎨 Toasts personalizados
    private fun mostrarToastError(mensaje: String) {
        Toast.makeText(this, "❌ $mensaje", Toast.LENGTH_SHORT).apply {
            setGravity(Gravity.TOP or Gravity.CENTER_HORIZONTAL, 0, 100)
        }.show()
    }

    private fun mostrarToastExito(mensaje: String) {
        Toast.makeText(this, "✅ $mensaje", Toast.LENGTH_SHORT).apply {
            setGravity(Gravity.TOP or Gravity.CENTER_HORIZONTAL, 0, 100)
        }.show()
    }

    // 🎉 Diálogo de bienvenida
    private fun mostrarDialogoBienvenida(nombre: String) {
        MaterialAlertDialogBuilder(this)
            .setTitle("🎉 ¡Bienvenido!")
            .setMessage("Hola, $nombre\n\n¡Has iniciado sesión correctamente!")
            .setPositiveButton("Continuar") { dialog, _ ->
                dialog.dismiss()
                mostrarToastExito("Sesión iniciada")
                startActivity(Intent(this, MenuActivity::class.java))
                finish()
            }
            .setCancelable(false)
            .show()
    }

    private fun mostrarDialogoRecuperarContrasena() {
        Toast.makeText(this, "Función aún no implementada", Toast.LENGTH_SHORT).show()
    }
}
