package com.example.appalertaya

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.google.android.material.appbar.CollapsingToolbarLayout
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.card.MaterialCardView
import com.google.android.material.chip.Chip
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class DetalleReportesActivity : AppCompatActivity() {

    private lateinit var txtTitle: TextView
    private lateinit var txtDescription: TextView
    private lateinit var txtAddress: TextView
    private lateinit var txtFecha: TextView
    private lateinit var imgReport: ImageView
    private lateinit var chipTipo: Chip
    private lateinit var chipEstado: Chip
    private lateinit var collapsingToolbar: CollapsingToolbarLayout
    private lateinit var btnCompartir: MaterialCardView
    private lateinit var btnVerMapa: MaterialCardView
    private lateinit var btnEditar: MaterialCardView
    private lateinit var btnEliminar: MaterialCardView
    private lateinit var btnFavorito: ImageView
    private lateinit var cardUrgencia: MaterialCardView

    private var direccionCompleta: String = ""
    private var tituloReporte: String = ""
    private var descripcionReporte: String = ""
    private var fotoUrl: String = ""
    private var isFavorito: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detalle_reportes)

        // 🔹 Inicializar views
        inicializarVistas()

        // 🔹 Configurar Toolbar
        configurarToolbar()

        // 🔹 Recibir y mostrar datos
        cargarDatosReporte()

        // 🔹 Configurar botones de acción
        configurarBotonesAccion()

        // 🔹 Configurar BottomNavigation
        configurarBottomNavigation()

        // 🔹 Animaciones de entrada
        animarEntrada()
    }

    private fun inicializarVistas() {
        txtTitle = findViewById(R.id.txtTitle)
        txtDescription = findViewById(R.id.txtDescription)
        txtAddress = findViewById(R.id.txtAddress)
        txtFecha = findViewById(R.id.txtFecha)
        imgReport = findViewById(R.id.imgReport)
        chipTipo = findViewById(R.id.chipTipo)
        chipEstado = findViewById(R.id.chipEstado)
        collapsingToolbar = findViewById(R.id.collapsingToolbar)
        btnCompartir = findViewById(R.id.btnCompartir)
        btnVerMapa = findViewById(R.id.btnVerMapa)
        btnEditar = findViewById(R.id.btnEditar)
        btnEliminar = findViewById(R.id.btnEliminar)
        btnFavorito = findViewById(R.id.btnFavorito)
        cardUrgencia = findViewById(R.id.cardUrgencia)
    }

    private fun configurarToolbar() {
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbarDetalle)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setDisplayShowHomeEnabled(true)

        toolbar.setNavigationOnClickListener {
            onBackPressed()
        }

        // Configurar botón de favorito
        btnFavorito.setOnClickListener {
            toggleFavorito()
        }
    }

    private fun cargarDatosReporte() {
        // 🔹 Recibir datos del Intent
        tituloReporte = intent.getStringExtra("titulo") ?: "Sin título"
        descripcionReporte = intent.getStringExtra("descripcion") ?: "Sin descripción"
        val tipo = intent.getStringExtra("tipo") ?: "General"
        direccionCompleta = intent.getStringExtra("direccion") ?: "Sin ubicación"
        val fecha = intent.getStringExtra("fecha") ?: "Fecha no disponible"
        fotoUrl = intent.getStringExtra("foto") ?: ""
        val estado = intent.getStringExtra("estado") ?: "Pendiente"
        val urgente = intent.getBooleanExtra("urgente", false)

        // 🔹 Configurar título en CollapsingToolbar
        collapsingToolbar.title = tituloReporte

        // 🔹 Mostrar datos en las vistas
        txtTitle.text = tituloReporte
        txtDescription.text = descripcionReporte
        txtAddress.text = direccionCompleta
        txtFecha.text = fecha

        // 🔹 Configurar Chip de tipo
        chipTipo.text = tipo
        configurarChipTipo(tipo)

        // 🔹 Configurar Chip de estado
        chipEstado.text = estado
        configurarChipEstado(estado)

        // 🔹 Mostrar badge de urgencia si aplica
        if (urgente) {
            cardUrgencia.visibility = View.VISIBLE
            cardUrgencia.startAnimation(
                AnimationUtils.loadAnimation(this, android.R.anim.fade_in)
            )
        }

        // 🔹 Cargar imagen
        cargarImagen()
    }

    private fun configurarChipTipo(tipo: String) {
        val color = when (tipo.lowercase()) {
            "incendio" -> android.graphics.Color.parseColor("#FF5722")
            "robo" -> android.graphics.Color.parseColor("#F44336")
            "accidente" -> android.graphics.Color.parseColor("#FF9800")
            "emergencia médica" -> android.graphics.Color.parseColor("#E91E63")
            "desastre natural" -> android.graphics.Color.parseColor("#9C27B0")
            "vandalismo" -> android.graphics.Color.parseColor("#673AB7")
            "basura acumulada" -> android.graphics.Color.parseColor("#795548")
            else -> android.graphics.Color.parseColor("#4CAF50")
        }
        chipTipo.chipBackgroundColor = android.content.res.ColorStateList.valueOf(color)
    }

    private fun configurarChipEstado(estado: String) {
        val color = when (estado.lowercase()) {
            "pendiente" -> android.graphics.Color.parseColor("#FFA726")
            "en proceso" -> android.graphics.Color.parseColor("#42A5F5")
            "resuelto" -> android.graphics.Color.parseColor("#66BB6A")
            "rechazado" -> android.graphics.Color.parseColor("#EF5350")
            "cancelado" -> android.graphics.Color.parseColor("#9E9E9E")
            else -> android.graphics.Color.parseColor("#757575")
        }
        chipEstado.chipBackgroundColor = android.content.res.ColorStateList.valueOf(color)
    }

    private fun cargarImagen() {
        if (fotoUrl.isNotEmpty()) {
            // Si la URL no empieza con http, agregamos el dominio
            val imagenCompleta = if (!fotoUrl.startsWith("http")) {
                "https://www.inkadroid.com/alertaya/uploads/$fotoUrl"
            } else {
                fotoUrl
            }

            Glide.with(this)
                .load(imagenCompleta)
                .placeholder(R.drawable.ic_paisaje)
                .error(R.drawable.ic_broken_image)
                .transition(DrawableTransitionOptions.withCrossFade())
                .centerCrop()
                .into(imgReport)
        } else {
            imgReport.setImageResource(R.drawable.ic_paisaje)
        }
    }


    private fun configurarBotonesAccion() {
        // 🔹 Botón Compartir
        btnCompartir.setOnClickListener {
            animarClick(it)
            compartirReporte()
        }

        // 🔹 Botón Ver en Mapa
        btnVerMapa.setOnClickListener {
            animarClick(it)
            abrirEnMapa()
        }

        // 🔹 Botón Editar
        btnEditar.setOnClickListener {
            animarClick(it)
            editarReporte()
        }

        // 🔹 Botón Eliminar
        btnEliminar.setOnClickListener {
            animarClick(it)
            mostrarDialogoEliminar()
        }
    }

    private fun compartirReporte() {
        val textoCompartir = """
            🚨 Reporte de Alerta Ya
            
            📋 Título: $tituloReporte
            📍 Ubicación: $direccionCompleta
            📝 Descripción: $descripcionReporte
            
            📱 Compartido desde Alerta Ya App
        """.trimIndent()

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, "Reporte: $tituloReporte")
            putExtra(Intent.EXTRA_TEXT, textoCompartir)
        }

        startActivity(Intent.createChooser(intent, "Compartir reporte mediante..."))
    }

    private fun abrirEnMapa() {
        try {
            val uri = Uri.parse("geo:0,0?q=${Uri.encode(direccionCompleta)}")
            val mapIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                setPackage("com.google.android.apps.maps")
            }
            startActivity(mapIntent)
        } catch (e: Exception) {
            val uri = Uri.parse("https://www.google.com/maps/search/?api=1&query=${Uri.encode(direccionCompleta)}")
            val browserIntent = Intent(Intent.ACTION_VIEW, uri)
            startActivity(browserIntent)
        }
    }

    private fun editarReporte() {
        Toast.makeText(
            this,
            "🔧 Función de edición próximamente",
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun mostrarDialogoEliminar() {
        MaterialAlertDialogBuilder(this)
            .setTitle("⚠️ Eliminar Reporte")
            .setMessage("¿Estás seguro de que deseas eliminar este reporte?\n\nEsta acción no se puede deshacer.")
            .setPositiveButton("Eliminar") { dialog, _ ->
                dialog.dismiss()
                eliminarReporte()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .setIcon(android.R.drawable.ic_dialog_alert)
            .show()
    }

    private fun eliminarReporte() {
        // Aquí implementarás la lógica real de eliminación
        Toast.makeText(
            this,
            "✅ Reporte eliminado correctamente",
            Toast.LENGTH_SHORT
        ).show()

        // Regresar a la lista de reportes
        finish()
    }

    private fun toggleFavorito() {
        isFavorito = !isFavorito

        if (isFavorito) {
            btnFavorito.setImageResource(android.R.drawable.btn_star_big_on)
            Toast.makeText(this, "❤️ Agregado a favoritos", Toast.LENGTH_SHORT).show()
        } else {
            btnFavorito.setImageResource(R.drawable.ic_favorite_border)
            Toast.makeText(this, "💔 Removido de favoritos", Toast.LENGTH_SHORT).show()
        }

        // Animación del botón
        btnFavorito.animate()
            .scaleX(1.3f)
            .scaleY(1.3f)
            .setDuration(150)
            .withEndAction {
                btnFavorito.animate()
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(150)
                    .start()
            }
            .start()
    }

    private fun animarClick(view: View) {
        view.animate()
            .scaleX(0.95f)
            .scaleY(0.95f)
            .setDuration(100)
            .withEndAction {
                view.animate()
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(100)
                    .start()
            }
            .start()
    }

    private fun animarEntrada() {
        // Animación para las cards con delay progresivo
        val cards = listOf(
            findViewById<MaterialCardView>(R.id.btnCompartir),
            findViewById<MaterialCardView>(R.id.btnVerMapa),
            findViewById<MaterialCardView>(R.id.btnEditar),
            findViewById<MaterialCardView>(R.id.btnEliminar)
        )

        cards.forEachIndexed { index, card ->
            card.alpha = 0f
            card.translationY = 50f
            card.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(400)
                .setStartDelay((index * 80).toLong())
                .start()
        }
    }

    private fun configurarBottomNavigation() {
        val bottomNavigation = findViewById<BottomNavigationView>(R.id.bottomNavigation)
        bottomNavigation.selectedItemId = R.id.nav_reportes

        bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_mapa -> {
                    startActivity(Intent(this, MenuActivity::class.java))
                    finish()
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                    true
                }
                R.id.nav_reportes -> {
                    startActivity(Intent(this, MisReportesActivity::class.java))
                    finish()
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                    true
                }
                R.id.nav_perfil -> {
                    startActivity(Intent(this, PerfilActivity::class.java))
                    finish()
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                    true
                }
                else -> false
            }
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }
}