package com.example.appalertaya.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.appalertaya.Reporte
import com.example.appalertaya.ReportesContract

class ReportesDBHelper(context: Context) : SQLiteOpenHelper(
    context,
    ReportesContract.DATABASE_NAME,
    null,
    ReportesContract.DATABASE_VERSION
) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(ReportesContract.ReporteEntry.SQL_CREATE_TABLE)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Si hay cambios en la versión, elimina y recrea la tabla
        db.execSQL(ReportesContract.ReporteEntry.SQL_DROP_TABLE)
        onCreate(db)
    }

    /**
     * Inserta un nuevo reporte en la base de datos
     */
    fun insertarReporte(
        titulo: String,
        descripcion: String,
        tipo: String,
        direccion: String,
        latitud: Double,
        longitud: Double,
        foto: String?,
        fecha: String,
        estado: String = ReportesContract.ReporteEntry.Estados.PENDIENTE
    ): Long {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(ReportesContract.ReporteEntry.COLUMN_TITULO, titulo)
            put(ReportesContract.ReporteEntry.COLUMN_DESCRIPCION, descripcion)
            put(ReportesContract.ReporteEntry.COLUMN_TIPO, tipo)
            put(ReportesContract.ReporteEntry.COLUMN_DIRECCION, direccion)
            put(ReportesContract.ReporteEntry.COLUMN_LATITUD, latitud)
            put(ReportesContract.ReporteEntry.COLUMN_LONGITUD, longitud)
            put(ReportesContract.ReporteEntry.COLUMN_FOTO, foto)
            put(ReportesContract.ReporteEntry.COLUMN_FECHA, fecha)
            put(ReportesContract.ReporteEntry.COLUMN_ESTADO, estado)
        }

        return db.insert(ReportesContract.ReporteEntry.TABLE_NAME, null, values)
    }

    /**
     * Obtiene todos los reportes
     */
    fun obtenerReportes(): List<Reporte> {
        val reportes = mutableListOf<Reporte>()
        val db = readableDatabase

        val cursor = db.rawQuery(ReportesContract.ReporteEntry.SQL_SELECT_ALL, null)

        cursor.use {
            if (it.moveToFirst()) {
                do {
                    val reporte = Reporte(
                        id = it.getInt(it.getColumnIndexOrThrow(ReportesContract.ReporteEntry.COLUMN_ID)),
                        titulo = it.getString(it.getColumnIndexOrThrow(ReportesContract.ReporteEntry.COLUMN_TITULO)),
                        descripcion = it.getString(it.getColumnIndexOrThrow(ReportesContract.ReporteEntry.COLUMN_DESCRIPCION)),
                        tipo = it.getString(it.getColumnIndexOrThrow(ReportesContract.ReporteEntry.COLUMN_TIPO)),
                        direccion = it.getString(it.getColumnIndexOrThrow(ReportesContract.ReporteEntry.COLUMN_DIRECCION)),
                        latitud = it.getDouble(it.getColumnIndexOrThrow(ReportesContract.ReporteEntry.COLUMN_LATITUD)),
                        longitud = it.getDouble(it.getColumnIndexOrThrow(ReportesContract.ReporteEntry.COLUMN_LONGITUD)),
                        foto = it.getString(it.getColumnIndexOrThrow(ReportesContract.ReporteEntry.COLUMN_FOTO)),
                        fecha = it.getString(it.getColumnIndexOrThrow(ReportesContract.ReporteEntry.COLUMN_FECHA))
                    )
                    reportes.add(reporte)
                } while (it.moveToNext())
            }
        }

        return reportes
    }

    /**
     * Obtiene reportes por tipo
     */
    fun obtenerReportesPorTipo(tipo: String): List<Reporte> {
        val reportes = mutableListOf<Reporte>()
        val db = readableDatabase

        val cursor = db.rawQuery(
            ReportesContract.ReporteEntry.getSqlSelectByTipo(tipo),
            null
        )

        cursor.use {
            if (it.moveToFirst()) {
                do {
                    val reporte = crearReporteDesdeRow(it)
                    reportes.add(reporte)
                } while (it.moveToNext())
            }
        }

        return reportes
    }

    /**
     * Obtiene un reporte por ID
     */
    fun obtenerReportePorId(id: Int): Reporte? {
        val db = readableDatabase
        val cursor = db.query(
            ReportesContract.ReporteEntry.TABLE_NAME,
            null,
            "${ReportesContract.ReporteEntry.COLUMN_ID} = ?",
            arrayOf(id.toString()),
            null,
            null,
            null
        )

        cursor.use {
            if (it.moveToFirst()) {
                return crearReporteDesdeRow(it)
            }
        }

        return null
    }

    /**
     * Actualiza el estado de un reporte
     */
    fun actualizarEstado(id: Int, nuevoEstado: String): Int {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(ReportesContract.ReporteEntry.COLUMN_ESTADO, nuevoEstado)
        }

        return db.update(
            ReportesContract.ReporteEntry.TABLE_NAME,
            values,
            "${ReportesContract.ReporteEntry.COLUMN_ID} = ?",
            arrayOf(id.toString())
        )
    }

    /**
     * Elimina un reporte
     */
    fun eliminarReporte(id: Int): Int {
        val db = writableDatabase
        return db.delete(
            ReportesContract.ReporteEntry.TABLE_NAME,
            "${ReportesContract.ReporteEntry.COLUMN_ID} = ?",
            arrayOf(id.toString())
        )
    }

    /**
     * Obtiene el conteo de reportes por tipo
     */
    fun contarReportesPorTipo(): Map<String, Int> {
        val conteo = mutableMapOf<String, Int>()
        val db = readableDatabase

        val query = """
            SELECT ${ReportesContract.ReporteEntry.COLUMN_TIPO}, COUNT(*) as total
            FROM ${ReportesContract.ReporteEntry.TABLE_NAME}
            GROUP BY ${ReportesContract.ReporteEntry.COLUMN_TIPO}
        """

        val cursor = db.rawQuery(query, null)

        cursor.use {
            if (it.moveToFirst()) {
                do {
                    val tipo = it.getString(0)
                    val total = it.getInt(1)
                    conteo[tipo] = total
                } while (it.moveToNext())
            }
        }

        return conteo
    }

    /**
     * Elimina todos los reportes
     */
    fun eliminarTodos(): Int {
        val db = writableDatabase
        return db.delete(ReportesContract.ReporteEntry.TABLE_NAME, null, null)
    }

    /**
     * Función auxiliar para crear un objeto Reporte desde un cursor
     */
    private fun crearReporteDesdeRow(cursor: Cursor): Reporte {
        return Reporte(
            id = cursor.getInt(cursor.getColumnIndexOrThrow(ReportesContract.ReporteEntry.COLUMN_ID)),
            titulo = cursor.getString(cursor.getColumnIndexOrThrow(ReportesContract.ReporteEntry.COLUMN_TITULO)),
            descripcion = cursor.getString(cursor.getColumnIndexOrThrow(ReportesContract.ReporteEntry.COLUMN_DESCRIPCION)),
            tipo = cursor.getString(cursor.getColumnIndexOrThrow(ReportesContract.ReporteEntry.COLUMN_TIPO)),
            direccion = cursor.getString(cursor.getColumnIndexOrThrow(ReportesContract.ReporteEntry.COLUMN_DIRECCION)),
            latitud = cursor.getDouble(cursor.getColumnIndexOrThrow(ReportesContract.ReporteEntry.COLUMN_LATITUD)),
            longitud = cursor.getDouble(cursor.getColumnIndexOrThrow(ReportesContract.ReporteEntry.COLUMN_LONGITUD)),
            foto = cursor.getString(cursor.getColumnIndexOrThrow(ReportesContract.ReporteEntry.COLUMN_FOTO)),
            fecha = cursor.getString(cursor.getColumnIndexOrThrow(ReportesContract.ReporteEntry.COLUMN_FECHA))
        )
    }
}