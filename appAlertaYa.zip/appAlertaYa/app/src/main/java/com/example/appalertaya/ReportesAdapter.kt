package com.example.appalertaya

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.request.RequestOptions
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class ReportesAdapter(
    private val reportes: List<Reporte>,
    private val onItemClick: (Reporte) -> Unit
) : RecyclerView.Adapter<ReportesAdapter.ReporteViewHolder>() {

    class ReporteViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val imgReporte: ImageView = view.findViewById(R.id.imgReporte)
        val txtTitulo: TextView = view.findViewById(R.id.txtTitulo)
        val txtEstado: TextView = view.findViewById(R.id.txtEstado)

        val txtDescripcion: TextView = view.findViewById(R.id.txtDescripcion)
        val txtFecha: TextView = view.findViewById(R.id.txtFecha)
        val txtTipo: TextView = view.findViewById(R.id.txtTipo)

        fun bind(reporte: Reporte, onClick: (Reporte) -> Unit) {
            // Título
            txtTitulo.text = reporte.titulo ?: "Sin título"

            // Ubicación/Descripción
            txtDescripcion.text = reporte.direccion ?: reporte.descripcion ?: "Sin ubicación"

            // Tipo con emoji
            txtTipo.text = obtenerTipoConEmoji(reporte.tipo)

            txtEstado.text = "Estado: ${reporte.estado ?: "Pendiente"}"

            // Fecha formateada
            txtFecha.text = formatearFecha(reporte.fecha)

            // Cargar imagen con Glide
            cargarImagen(reporte)

            // Click listener
            itemView.setOnClickListener { onClick(reporte) }
        }

        private fun obtenerTipoConEmoji(tipo: String?): String {
            return when (tipo) {
                "Basura acumulada" -> "🗑️ BASURA"
                "Fuga de agua" -> "💧 FUGA"
                "Bache en la calle" -> "🕳️ BACHE"
                "Luminaria dañada" -> "💡 LUMINARIA"
                "Grafiti" -> "🎨 GRAFITI"
                "Árbol caído" -> "🌳 ÁRBOL"
                else -> "📌 ${tipo?.uppercase() ?: "OTRO"}"
            }
        }

        private fun cargarImagen(reporte: Reporte) {
            if (!reporte.foto.isNullOrEmpty()) {
                // Si la foto no empieza con http, agregamos el dominio del servidor
                val imagenUrl = if (!reporte.foto.startsWith("http")) {
                    "https://www.inkadroid.com/alertaya/uploads/${reporte.foto}"
                } else {
                    reporte.foto
                }

                Glide.with(itemView.context)
                    .load(imagenUrl)
                    .apply(
                        RequestOptions()
                            .transform(RoundedCorners(24))
                            .centerCrop()
                    )
                    .placeholder(R.drawable.ic_paisaje)
                    .error(R.drawable.ic_broken_image)
                    .into(imgReporte)
            } else {
                cargarImagenPorDefecto()
            }
        }


        private fun cargarImagenPorDefecto() {
            Glide.with(itemView.context)
                .load(R.drawable.ic_paisaje)
                .apply(
                    RequestOptions()
                        .transform(RoundedCorners(24))
                        .centerInside()
                )
                .into(imgReporte)
        }

        private fun formatearFecha(fecha: String?): String {
            if (fecha.isNullOrEmpty()) return "Fecha desconocida"

            return try {
                val sdfEntrada = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                val fechaDate = sdfEntrada.parse(fecha) ?: return fecha

                val ahora = Calendar.getInstance()
                val fechaCalendar = Calendar.getInstance().apply { time = fechaDate }

                // Calcular diferencia en milisegundos
                val diffMs = ahora.timeInMillis - fechaCalendar.timeInMillis
                val diffDias = (diffMs / (1000 * 60 * 60 * 24)).toInt()

                when {
                    diffDias == 0 -> {
                        // Mismo día
                        val diffHoras = (diffMs / (1000 * 60 * 60)).toInt()
                        when {
                            diffHoras == 0 -> {
                                val diffMin = (diffMs / (1000 * 60)).toInt()
                                if (diffMin < 1) "Hace un momento"
                                else "Hace $diffMin min"
                            }
                            diffHoras == 1 -> "Hace 1 hora"
                            else -> "Hace $diffHoras horas"
                        }
                    }
                    diffDias == 1 -> "Ayer"
                    diffDias < 7 -> "Hace $diffDias días"
                    diffDias < 30 -> {
                        val semanas = diffDias / 7
                        if (semanas == 1) "Hace 1 semana"
                        else "Hace $semanas semanas"
                    }
                    diffDias < 365 -> {
                        val meses = diffDias / 30
                        if (meses == 1) "Hace 1 mes"
                        else "Hace $meses meses"
                    }
                    else -> {
                        // Mostrar fecha completa
                        val sdfSalida = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                        sdfSalida.format(fechaDate)
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                fecha
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ReporteViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_reporte, parent, false)
        return ReporteViewHolder(view)
    }

    override fun onBindViewHolder(holder: ReporteViewHolder, position: Int) {
        holder.bind(reportes[position], onItemClick)
    }

    override fun getItemCount(): Int = reportes.size
}