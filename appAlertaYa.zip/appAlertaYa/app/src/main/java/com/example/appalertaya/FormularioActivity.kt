package com.example.appalertaya

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.location.Geocoder
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import android.util.Base64
import androidx.appcompat.app.AlertDialog
import androidx.core.content.FileProvider
import kotlinx.coroutines.*
import java.util.Locale
import android.content.pm.PackageManager
import android.view.View

class FormularioActivity : AppCompatActivity() {

    private lateinit var spinnerTipo: Spinner
    private lateinit var edtDescripcion: EditText
    private lateinit var edtUbicacion: EditText
    private lateinit var btnEnviar: Button
    private lateinit var btnTomarFoto: Button
    private lateinit var imgEvidencia: ImageView
    private lateinit var overlayNoFoto: View   // ← agregado

    private var bitmap: Bitmap? = null
    private var latitud: Double = 0.0
    private var longitud: Double = 0.0

    private val REQUEST_TOMAR_FOTO = 100
    private val REQUEST_GALERIA = 101
    private val REQUEST_CAMARA_PERMISSION = 200

    private var fotoUri: Uri? = null
    private var fotoPath: String? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_formulario)

        spinnerTipo = findViewById(R.id.spinnerTipo)
        edtDescripcion = findViewById(R.id.edtDescripcion)
        edtUbicacion = findViewById(R.id.edtUbicacion)
        btnEnviar = findViewById(R.id.btnEnviar)
        btnTomarFoto = findViewById(R.id.btnTomarFoto)
        imgEvidencia = findViewById(R.id.imgEvidencia)
        overlayNoFoto = findViewById(R.id.overlayNoFoto)   // ← agregado

        edtUbicacion.isEnabled = false

        latitud = intent.getDoubleExtra("latitud", 0.0)
        longitud = intent.getDoubleExtra("longitud", 0.0)

        if (latitud != 0.0 && longitud != 0.0) {
            obtenerDireccionDesdeCoordenadas(latitud, longitud)
        } else {
            edtUbicacion.setText("Ubicación no disponible")
        }

        val tipos = arrayOf(
            "Basura acumulada", "Fuga de agua", "Bache en la calle",
            "Luminaria dañada", "Grafiti", "Árbol caído", "Otro"
        )
        spinnerTipo.adapter =
            ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, tipos)

        btnTomarFoto.setOnClickListener { mostrarDialogoSeleccionImagen() }
        btnEnviar.setOnClickListener { enviarReporte() }
    }

    // ==================================================================================
    private fun obtenerDireccionDesdeCoordenadas(lat: Double, lon: Double) {
        edtUbicacion.setText("📍 Obteniendo dirección...")
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val geocoder = Geocoder(this@FormularioActivity, Locale.getDefault())
                val direcciones = geocoder.getFromLocation(lat, lon, 1)
                withContext(Dispatchers.Main) {
                    if (!direcciones.isNullOrEmpty()) {
                        val dir = direcciones[0]
                        val direccion = listOfNotNull(
                            dir.thoroughfare, dir.subThoroughfare,
                            dir.locality, dir.adminArea, dir.countryName
                        ).joinToString(", ")
                        edtUbicacion.setText(direccion)
                    } else {
                        edtUbicacion.setText("Lat: $lat, Lon: $lon")
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    edtUbicacion.setText("Lat: $lat, Lon: $lon")
                }
            }
        }
    }

    // ==================================================================================
    private fun enviarReporte() {

        val tipo = spinnerTipo.selectedItem.toString()
        val descripcion = edtDescripcion.text.toString().trim()
        val direccion = edtUbicacion.text.toString().trim()
        val fecha = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())

        val prefs = getSharedPreferences("UserSession", MODE_PRIVATE)
        val userId = prefs.getInt("user_id", -1)

        if (userId == -1) {
            Toast.makeText(this, "⚠️ Inicia sesión nuevamente", Toast.LENGTH_LONG).show()
            return
        }

        val titulo = "$tipo en $direccion"
        val imagenBase64 = bitmap?.let { convertirImagenABase64(it) } ?: ""

        val url = "https://www.inkadroid.com/alertaya/api/insert_reporte.php"

        val request = object : StringRequest(
            Method.POST, url,
            { response ->
                try {
                    val json = JSONObject(response)
                    if (json.getString("status") == "success") {
                        Toast.makeText(this, "✅ Reporte enviado correctamente", Toast.LENGTH_LONG)
                            .show()
                        finish()
                    } else {
                        Toast.makeText(
                            this,
                            "❌ ${json.getString("message")}",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "⚠️ Error al procesar respuesta", Toast.LENGTH_LONG).show()
                }
            },
            { error ->
                Toast.makeText(this, "🚫 Error de red: ${error.message}", Toast.LENGTH_LONG).show()
            }
        ) {
            override fun getParams(): MutableMap<String, String> {
                return hashMapOf(
                    "titulo" to titulo,
                    "descripcion" to descripcion,
                    "tipo" to tipo,
                    "direccion" to direccion,
                    "latitud" to latitud.toString(),
                    "longitud" to longitud.toString(),
                    "fecha" to fecha,
                    "estado" to "pendiente",
                    "user_id" to userId.toString(),
                    "imagen" to imagenBase64
                )
            }
        }

        Volley.newRequestQueue(this).add(request)
        Toast.makeText(this, "📤 Enviando reporte...", Toast.LENGTH_SHORT).show()
    }

    // ==================================================================================
    private fun convertirImagenABase64(bitmap: Bitmap): String {

        val maxSize = 2048
        val resized = if (bitmap.width > maxSize || bitmap.height > maxSize) {
            val ratio = bitmap.width.toFloat() / bitmap.height
            val newW: Int
            val newH: Int
            if (ratio > 1) {
                newW = maxSize
                newH = (maxSize / ratio).toInt()
            } else {
                newH = maxSize
                newW = (maxSize * ratio).toInt()
            }
            Bitmap.createScaledBitmap(bitmap, newW, newH, true)
        } else {
            bitmap
        }

        val stream = ByteArrayOutputStream()
        resized.compress(Bitmap.CompressFormat.JPEG, 80, stream)
        val bytes = stream.toByteArray()

        return Base64.encodeToString(bytes, Base64.DEFAULT)
    }

    // ==================================================================================
    private fun mostrarDialogoSeleccionImagen() {
        val opciones = arrayOf("📷 Tomar foto", "🖼️ Elegir de galería")
        AlertDialog.Builder(this)
            .setTitle("Agregar imagen")
            .setItems(opciones) { _, which ->
                when (which) {
                    0 -> tomarFoto()
                    1 -> abrirGaleria()
                }
            }.show()
    }

    // ==================================================================================
    private fun tomarFoto() {
        solicitarPermisoCamara()
    }

    private fun solicitarPermisoCamara() {
        if (checkSelfPermission(android.Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED) {

            requestPermissions(arrayOf(android.Manifest.permission.CAMERA), REQUEST_CAMARA_PERMISSION)

        } else {
            abrirCamara()
        }
    }

    private fun abrirCamara() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        val file = crearArchivoImagen()
        file?.let {
            fotoUri = FileProvider.getUriForFile(
                this,
                "${packageName}.fileprovider",
                it
            )
            intent.putExtra(MediaStore.EXTRA_OUTPUT, fotoUri)
            startActivityForResult(intent, REQUEST_TOMAR_FOTO)
        }
    }

    // ==================================================================================
    private fun abrirGaleria() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, REQUEST_GALERIA)
    }

    private fun crearArchivoImagen(): File? {
        val name = "IMG_${System.currentTimeMillis()}.jpg"
        val dir = getExternalFilesDir("Pictures")
        val file = File(dir, name)
        fotoPath = file.absolutePath
        return file
    }

    // ==================================================================================
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {

                REQUEST_TOMAR_FOTO -> {
                    fotoPath?.let { path ->
                        val img = BitmapFactory.decodeFile(path)
                        if (img != null) {
                            bitmap = img
                            imgEvidencia.setImageBitmap(img)

                            // 🔥 OCULTAR OVERLAY PARA MOSTRAR FOTO
                            overlayNoFoto.visibility = View.GONE
                        } else {
                            Toast.makeText(this, "Error al procesar imagen capturada", Toast.LENGTH_SHORT).show()
                        }
                    }
                }

                REQUEST_GALERIA -> {
                    val uri = data?.data
                    val img = MediaStore.Images.Media.getBitmap(contentResolver, uri)
                    bitmap = img
                    imgEvidencia.setImageBitmap(img)

                    // 🔥 OCULTAR OVERLAY PARA MOSTRAR FOTO
                    overlayNoFoto.visibility = View.GONE
                }
            }
        }
    }

    // ==================================================================================
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == REQUEST_CAMARA_PERMISSION) {
            if (grantResults.isNotEmpty() &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                abrirCamara()

            } else {
                Toast.makeText(this, "⚠️ Permiso de cámara denegado", Toast.LENGTH_LONG).show()
            }
        }
    }
}
