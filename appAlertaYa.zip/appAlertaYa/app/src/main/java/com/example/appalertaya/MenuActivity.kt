package com.example.appalertaya

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.cardview.widget.CardView
import androidx.core.app.ActivityCompat
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.appalertaya.data.ReportesDBHelper
import com.google.android.gms.common.api.ResolvableApiException
import com.google.android.gms.location.*
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.navigation.NavigationView

class MenuActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var locationCallback: LocationCallback
    private lateinit var locationRequest: LocationRequest
    private lateinit var settingsClient: SettingsClient

    private var ubicacionActual: LatLng? = null
    private var marcador: Marker? = null

    // UI Components
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var navView: NavigationView
    private lateinit var toolbar: Toolbar
    private lateinit var toggle: ActionBarDrawerToggle

    private lateinit var recyclerReportes: RecyclerView
    private lateinit var reportesAdapter: ReportesAdapter
    private lateinit var dbHelper: ReportesDBHelper

    private lateinit var cardMisIncidentes: CardView
    private lateinit var fabMostrarIncidentes: FloatingActionButton
    private lateinit var fabCentrarUbicacion: FloatingActionButton
    private lateinit var btnReportarIncidente: ExtendedFloatingActionButton

    private var incidentesVisibles = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)

        // Inicializar componentes
        inicializarComponentes()
        configurarMapa()
        configurarDrawer()
        configurarBottomNavigation()
        configurarBotones()
        configurarRecyclerView()

        // Configurar ubicación
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        settingsClient = LocationServices.getSettingsClient(this)

        locationRequest = LocationRequest.Builder(
            Priority.PRIORITY_HIGH_ACCURACY, 5000
        ).setMinUpdateIntervalMillis(2000).build()

        checkGPSSettings()

        locationCallback = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult) {
                for (location in locationResult.locations) {
                    actualizarUbicacion(location)
                }
            }
        }
    }

    private fun inicializarComponentes() {
        drawerLayout = findViewById(R.id.drawer_layout)
        navView = findViewById(R.id.nav_view)
        toolbar = findViewById(R.id.toolbar)
        cardMisIncidentes = findViewById(R.id.cardMisIncidentes)
        fabMostrarIncidentes = findViewById(R.id.fabMostrarIncidentes)
        fabCentrarUbicacion = findViewById(R.id.fabCentrarUbicacion)
        btnReportarIncidente = findViewById(R.id.btnReportarIncidente)
        recyclerReportes = findViewById(R.id.recyclerMisIncidentes)

        dbHelper = ReportesDBHelper(this)
    }

    private fun configurarMapa() {
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    private fun configurarDrawer() {
        navView.itemIconTintList = null
        setSupportActionBar(toolbar)

        // Quitar el título automático de la toolbar
        supportActionBar?.setDisplayShowTitleEnabled(false)

        toggle = ActionBarDrawerToggle(
            this, drawerLayout, toolbar,
            R.string.navigation_drawer_open,
            R.string.navigation_drawer_close
        )
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        navView.setNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_perfil -> {
                    startActivity(Intent(this, PerfilActivity::class.java))
                    true
                }
                R.id.nav_puntos -> {
                    mostrarToastInfo("Mis puntos - Próximamente")
                    true
                }
                R.id.nav_reportes -> {
                    startActivity(Intent(this, MisReportesActivity::class.java))
                    true
                }
                else -> false
            }.also {
                drawerLayout.closeDrawer(GravityCompat.START)
            }
        }
    }

    private fun configurarBottomNavigation() {
        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNavigation)
        bottomNav.selectedItemId = R.id.nav_mapa

        bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_mapa -> true
                R.id.nav_reportes -> {
                    startActivity(Intent(this, MisReportesActivity::class.java))
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                    true
                }
                R.id.nav_perfil -> {
                    startActivity(Intent(this, PerfilActivity::class.java))
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                    true
                }
                else -> false
            }
        }
    }

    private fun configurarBotones() {
        // Botón reportar incidente
        btnReportarIncidente.setOnClickListener {
            ubicacionActual?.let {
                val intent = Intent(this, FormularioActivity::class.java)
                intent.putExtra("latitud", it.latitude)
                intent.putExtra("longitud", it.longitude)
                startActivityForResult(intent, REQUEST_CODE_FORMULARIO)
                overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right)
            } ?: run {
                mostrarToastError("Esperando ubicación GPS...")
            }
        }

        // Botón mostrar/ocultar incidentes
        fabMostrarIncidentes.setOnClickListener {
            toggleIncidentes()
        }

        // Botón cerrar card de incidentes
        findViewById<View>(R.id.btnCerrarIncidentes).setOnClickListener {
            ocultarIncidentes()
        }

        // Botón centrar ubicación
        fabCentrarUbicacion.setOnClickListener {
            ubicacionActual?.let { ubicacion ->
                mMap.animateCamera(
                    CameraUpdateFactory.newLatLngZoom(ubicacion, 16f),
                    500,
                    null
                )
                mostrarToastInfo("📍 Centrado en tu ubicación")
            } ?: run {
                mostrarToastError("No se pudo obtener tu ubicación")
            }
        }
    }

    private fun configurarRecyclerView() {
        recyclerReportes.layoutManager = LinearLayoutManager(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        // Configurar estilo del mapa
        mMap.uiSettings.apply {
            isZoomControlsEnabled = false
            isCompassEnabled = true
            isMyLocationButtonEnabled = false
            isMapToolbarEnabled = false
        }

        if (ActivityCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1
            )
            return
        }

        iniciarActualizaciones()
        cargarReportes()

        // Listener para marcadores
        mMap.setOnMarkerClickListener { marker ->
            val tag = marker.tag
            if (tag is Reporte) {
                abrirDetalleReporte(tag)
            } else if (marker.title == "Mi ubicación") {
                mostrarToastInfo("📍 Esta es tu ubicación actual")
            }
            true
        }
    }

    private fun actualizarUbicacion(location: Location) {
        val userLatLng = LatLng(location.latitude, location.longitude)
        ubicacionActual = userLatLng

        if (marcador == null) {
            marcador = mMap.addMarker(
                MarkerOptions()
                    .position(userLatLng)
                    .title("Mi ubicación")
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE))
            )
            mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(userLatLng, 16f))
        } else {
            marcador?.position = userLatLng
        }
    }

    private fun iniciarActualizaciones() {
        if (ActivityCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            fusedLocationClient.requestLocationUpdates(
                locationRequest,
                locationCallback,
                mainLooper
            )
        }
    }

    private fun detenerActualizaciones() {
        fusedLocationClient.removeLocationUpdates(locationCallback)
    }

    private fun checkGPSSettings() {
        val builder = LocationSettingsRequest.Builder()
            .addLocationRequest(locationRequest)
        val task = settingsClient.checkLocationSettings(builder.build())

        task.addOnFailureListener { exception ->
            if (exception is ResolvableApiException) {
                try {
                    exception.startResolutionForResult(this, 2)
                } catch (sendEx: Exception) {
                    sendEx.printStackTrace()
                }
            }
        }
    }

    private fun cargarReportes() {
        if (!::mMap.isInitialized) return

        val reportes: List<Reporte> = dbHelper.obtenerReportes()

        reportesAdapter = ReportesAdapter(reportes) { reporte ->
            abrirDetalleReporte(reporte)
        }
        recyclerReportes.adapter = reportesAdapter

        // Limpiar marcadores previos (excepto el del usuario)
        mMap.clear()

        // Re-agregar marcador del usuario
        ubicacionActual?.let { ubicacion ->
            marcador = mMap.addMarker(
                MarkerOptions()
                    .position(ubicacion)
                    .title("Mi ubicación")
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE))
            )
        }

        // Agregar marcadores de reportes
        for (reporte in reportes) {
            val latLng = LatLng(reporte.latitud, reporte.longitud)
            val marker = mMap.addMarker(
                MarkerOptions()
                    .position(latLng)
                    .title(reporte.titulo)
                    .snippet(reporte.tipo)
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED))
            )
            marker?.tag = reporte
        }

        // Actualizar badge del FAB
        if (reportes.isNotEmpty()) {
            fabMostrarIncidentes.setImageResource(android.R.drawable.ic_dialog_info)
        }
    }

    private fun toggleIncidentes() {
        if (incidentesVisibles) {
            ocultarIncidentes()
        } else {
            mostrarIncidentes()
        }
    }

    private fun mostrarIncidentes() {
        cardMisIncidentes.visibility = View.VISIBLE
        incidentesVisibles = true
        fabMostrarIncidentes.setImageResource(android.R.drawable.ic_menu_close_clear_cancel)
    }

    private fun ocultarIncidentes() {
        cardMisIncidentes.visibility = View.GONE
        incidentesVisibles = false
        fabMostrarIncidentes.setImageResource(android.R.drawable.ic_dialog_info)
    }

    private fun abrirDetalleReporte(reporte: Reporte) {
        val intent = Intent(this, DetalleReportesActivity::class.java).apply {
            putExtra("titulo", reporte.titulo ?: "")
            putExtra("descripcion", reporte.descripcion ?: "")
            putExtra("tipo", reporte.tipo ?: "")
            putExtra("direccion", reporte.direccion ?: "")
            putExtra("latitud", reporte.latitud)
            putExtra("longitud", reporte.longitud)
            putExtra("fecha", reporte.fecha ?: "")
            putExtra("foto", reporte.foto ?: "")
        }
        startActivity(intent)
    }

    private fun mostrarToastInfo(mensaje: String) {
        Toast.makeText(this, mensaje, Toast.LENGTH_SHORT).show()
    }

    private fun mostrarToastError(mensaje: String) {
        Toast.makeText(this, "⚠️ $mensaje", Toast.LENGTH_SHORT).show()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1 && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            iniciarActualizaciones()
        } else {
            MaterialAlertDialogBuilder(this)
                .setTitle("⚠️ Permiso requerido")
                .setMessage("La app necesita acceso a tu ubicación para funcionar correctamente.")
                .setPositiveButton("Configurar") { _, _ ->
                    ActivityCompat.requestPermissions(
                        this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1
                    )
                }
                .setNegativeButton("Cancelar", null)
                .show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            2 -> {
                if (resultCode == Activity.RESULT_OK) {
                    iniciarActualizaciones()
                    mostrarToastInfo("✅ GPS activado")
                } else {
                    mostrarToastError("Debes activar la ubicación")
                }
            }
            REQUEST_CODE_FORMULARIO -> {
                if (resultCode == Activity.RESULT_OK) {
                    cargarReportes()
                    mostrarToastInfo("✅ Reporte agregado al mapa")
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        iniciarActualizaciones()
        cargarReportes()
    }

    override fun onPause() {
        super.onPause()
        detenerActualizaciones()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            drawerLayout.isDrawerOpen(GravityCompat.START) -> {
                drawerLayout.closeDrawer(GravityCompat.START)
            }
            incidentesVisibles -> {
                ocultarIncidentes()
            }
            else -> {
                MaterialAlertDialogBuilder(this)
                    .setTitle("Salir de AlertaYa")
                    .setMessage("¿Deseas cerrar la aplicación?")
                    .setPositiveButton("Salir") { _, _ ->
                        super.onBackPressed()
                    }
                    .setNegativeButton("Cancelar", null)
                    .show()
            }
        }
    }

    companion object {
        private const val REQUEST_CODE_FORMULARIO = 100
    }
}