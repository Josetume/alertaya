package com.example.appalertaya

import android.provider.BaseColumns

/**
 * Contrato de la base de datos para Reportes
 * Define la estructura de la tabla y sus columnas
 */
object ReportesContract {

    /**
     * Definición de la tabla de reportes
     */
    object ReporteEntry : BaseColumns {
        // Nombre de la tabla
        const val TABLE_NAME = "reportes"

        // Columnas de la tabla
        const val COLUMN_ID = BaseColumns._ID  // ID autoincremental
        const val COLUMN_TITULO = "titulo"
        const val COLUMN_DESCRIPCION = "descripcion"
        const val COLUMN_TIPO = "tipo"
        const val COLUMN_DIRECCION = "direccion"
        const val COLUMN_LATITUD = "latitud"
        const val COLUMN_LONGITUD = "longitud"
        const val COLUMN_FOTO = "foto"
        const val COLUMN_FECHA = "fecha"
        const val COLUMN_ESTADO = "estado"  // Para futuras mejoras (pendiente, resuelto, etc.)

        // Query de creación de la tabla
        const val SQL_CREATE_TABLE = """
            CREATE TABLE $TABLE_NAME (
                $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_TITULO TEXT NOT NULL,
                $COLUMN_DESCRIPCION TEXT,
                $COLUMN_TIPO TEXT NOT NULL,
                $COLUMN_DIRECCION TEXT,
                $COLUMN_LATITUD REAL NOT NULL,
                $COLUMN_LONGITUD REAL NOT NULL,
                $COLUMN_FOTO TEXT,
                $COLUMN_FECHA TEXT NOT NULL,
                $COLUMN_ESTADO TEXT DEFAULT 'pendiente'
            )
        """

        // Query para eliminar la tabla
        const val SQL_DROP_TABLE = "DROP TABLE IF EXISTS $TABLE_NAME"

        // Query para obtener todos los reportes ordenados por fecha
        const val SQL_SELECT_ALL = """
            SELECT * FROM $TABLE_NAME 
            ORDER BY $COLUMN_FECHA DESC
        """

        // Query para obtener reportes por tipo
        fun getSqlSelectByTipo(tipo: String) = """
            SELECT * FROM $TABLE_NAME 
            WHERE $COLUMN_TIPO = '$tipo'
            ORDER BY $COLUMN_FECHA DESC
        """

        // Query para obtener reportes por estado
        fun getSqlSelectByEstado(estado: String) = """
            SELECT * FROM $TABLE_NAME 
            WHERE $COLUMN_ESTADO = '$estado'
            ORDER BY $COLUMN_FECHA DESC
        """

        // Query para obtener reportes cercanos (dentro de un radio)
        fun getSqlSelectCercanos(lat: Double, lon: Double, radioKm: Double) = """
            SELECT *, 
            (6371 * acos(cos(radians($lat)) * cos(radians($COLUMN_LATITUD)) * 
            cos(radians($COLUMN_LONGITUD) - radians($lon)) + 
            sin(radians($lat)) * sin(radians($COLUMN_LATITUD)))) AS distancia
            FROM $TABLE_NAME
            HAVING distancia < $radioKm
            ORDER BY distancia ASC
        """

        // Tipos de incidentes válidos
        object TiposIncidente {
            const val BASURA_ACUMULADA = "Basura acumulada"
            const val FUGA_AGUA = "Fuga de agua"
            const val BACHE = "Bache en la calle"
            const val LUMINARIA = "Luminaria dañada"
            const val GRAFITI = "Grafiti"
            const val ARBOL_CAIDO = "Árbol caído"
            const val OTRO = "Otro"

            fun obtenerTodos() = listOf(
                BASURA_ACUMULADA,
                FUGA_AGUA,
                BACHE,
                LUMINARIA,
                GRAFITI,
                ARBOL_CAIDO,
                OTRO
            )
        }

        // Estados posibles de un reporte
        object Estados {
            const val PENDIENTE = "pendiente"
            const val EN_PROCESO = "en_proceso"
            const val RESUELTO = "resuelto"
            const val RECHAZADO = "rechazado"

            fun obtenerTodos() = listOf(
                PENDIENTE,
                EN_PROCESO,
                RESUELTO,
                RECHAZADO
            )
        }
    }

    // Versión de la base de datos
    const val DATABASE_VERSION = 2
    const val DATABASE_NAME = "AlertaYa.db"
}