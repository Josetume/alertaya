package com.example.appalertaya

data class Reporte(
    val id: Int = 0,                // opcional si usas BD
    val titulo: String,             // título o nombre del incidente
    val descripcion: String,        // lo que escribió el usuario
    val tipo: String,               // tipo de incidente (robo, basura, accidente, etc.)
    val direccion: String,          // dirección textual
    val latitud: Double,            // coordenadas
    val longitud: Double,           // coordenadas
    val fecha: String,              // fecha/hora
    val foto: String? = null,
    val estado: String? = null // ruta de la foto
)