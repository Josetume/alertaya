package com.example.appalertaya

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.google.android.material.bottomnavigation.BottomNavigationView
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

class PerfilActivity : AppCompatActivity() {

    private val REQUEST_IMAGE_CAPTURE = 1
    private lateinit var currentPhotoPath: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_perfil)

        // 🔹 Cargar datos del usuario guardados en SharedPreferences
        mostrarDatosUsuario()

        // 🔹 Botón de regreso
        val btnBack = findViewById<ImageView>(R.id.btn_back)
        btnBack.setOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }

        // 🔹 BottomNavigation configurado
        val bottomNavigation = findViewById<BottomNavigationView>(R.id.bottomNavigation)
        bottomNavigation.selectedItemId = R.id.nav_perfil

        bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_mapa -> {
                    startActivity(Intent(this, MenuActivity::class.java))
                    overridePendingTransition(0, 0)
                    true
                }

                R.id.nav_reportes -> {
                    startActivity(Intent(this, MisReportesActivity::class.java))
                    overridePendingTransition(0, 0)
                    true
                }

                R.id.nav_perfil -> true
                else -> false
            }
        }

        // 🔹 Imagen de perfil con cámara
        val profileImage = findViewById<ImageView>(R.id.profile_image)
        profileImage.setOnClickListener {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.CAMERA
                ) == PackageManager.PERMISSION_GRANTED
            ) {
                dispatchTakePictureIntent()
            } else {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 1)
            }
        }

        // 🔹 Botón de Cerrar Sesión
        val btnLogout = findViewById<Button>(R.id.btn_logout)
        btnLogout.setOnClickListener {
            mostrarDialogoCerrarSesion()
        }
    }

    // 🔹 Mostrar datos del usuario guardados
    private fun mostrarDatosUsuario() {
        val prefs = getSharedPreferences("UserSession", Context.MODE_PRIVATE)
        val nombre = prefs.getString("nombre", "Usuario")
        val correo = prefs.getString("correo", "Sin correo")
        val telefono = prefs.getString("telefono", "Sin teléfono")

        // Enlazamos los TextView del layout
        val txtNombre = findViewById<TextView>(R.id.profile_name)
        val txtCorreo = findViewById<TextView>(R.id.txt_email) // lo agregaremos en el XML
        val txtTelefono = findViewById<TextView>(R.id.txt_telefono)

        txtNombre.text = nombre
        txtCorreo.text = correo
        txtTelefono.text = telefono
    }

    // 🔹 Diálogo de confirmación de cierre de sesión
    private fun mostrarDialogoCerrarSesion() {
        val builder = AlertDialog.Builder(this, R.style.CustomDialogStyle)
        builder.setTitle("Cerrar sesión")
        builder.setMessage("¿Seguro que quieres cerrar sesión y volver al inicio?")
        builder.setPositiveButton("Sí, cerrar sesión") { dialog, _ ->
            dialog.dismiss()

            // 🔸 Borrar datos de sesión guardados
            val prefs = getSharedPreferences("UserSession", Context.MODE_PRIVATE)
            prefs.edit().clear().apply()

            // 🔸 Ir al inicio de sesión (MainActivity)
            val intent = Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }
        builder.setNegativeButton("Cancelar") { dialog, _ ->
            dialog.dismiss()
        }

        val dialog = builder.create()
        dialog.show()

        dialog.getButton(AlertDialog.BUTTON_POSITIVE)
            ?.setTextColor(ContextCompat.getColor(this, android.R.color.holo_red_dark))
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE)
            ?.setTextColor(ContextCompat.getColor(this, android.R.color.darker_gray))
    }

    // 🔹 Resultado de cámara
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            val imageView = findViewById<ImageView>(R.id.profile_image)
            val file = File(currentPhotoPath)
            val bitmap: Bitmap =
                MediaStore.Images.Media.getBitmap(contentResolver, Uri.fromFile(file))
            imageView.setImageBitmap(bitmap)
        }
    }

    // 🔹 Permisos
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            dispatchTakePictureIntent()
        }
    }

    // 🔹 Abrir cámara
    private fun dispatchTakePictureIntent() {
        Intent(MediaStore.ACTION_IMAGE_CAPTURE).also { takePictureIntent ->
            takePictureIntent.resolveActivity(packageManager)?.also {
                val photoFile: File? = try {
                    createImageFile()
                } catch (ex: IOException) {
                    null
                }
                photoFile?.also {
                    val photoURI: Uri = FileProvider.getUriForFile(
                        this,
                        "${applicationContext.packageName}.fileprovider",
                        it
                    )
                    takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI)
                    startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE)
                }
            }
        }
    }

    // 🔹 Crear archivo temporal
    @Throws(IOException::class)
    private fun createImageFile(): File {
        val timeStamp: String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val storageDir: File = getExternalFilesDir(null)!!
        return File.createTempFile(
            "JPEG_${timeStamp}_",
            ".jpg",
            storageDir
        ).apply {
            currentPhotoPath = absolutePath
        }
    }
}
