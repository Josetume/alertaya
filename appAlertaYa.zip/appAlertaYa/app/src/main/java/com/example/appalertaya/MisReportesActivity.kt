package com.example.appalertaya

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import java.text.SimpleDateFormat
import java.util.*

class MisReportesActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var tvTotalReportes: TextView
    private lateinit var tvReportesRecientes: TextView
    private lateinit var layoutSinReportes: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mis_reportes)

        inicializarComponentes()
        configurarToolbar()
        configurarBottomNavigation()
        cargarReportes()
    }

    private fun inicializarComponentes() {
        recyclerView = findViewById(R.id.recyclerReportes)
        tvTotalReportes = findViewById(R.id.tvTotalReportes)
        tvReportesRecientes = findViewById(R.id.tvReportesRecientes)
        layoutSinReportes = findViewById(R.id.layoutSinReportes)
    }

    private fun configurarToolbar() {
        val toolbar: androidx.appcompat.widget.Toolbar = findViewById(R.id.toolbar_mis_reportes)
        setSupportActionBar(toolbar)
        supportActionBar?.apply {
            setDisplayHomeAsUpEnabled(true)
            setDisplayShowHomeEnabled(true)
            setDisplayShowTitleEnabled(false)
        }
        toolbar.title = "Mis Reportes"
        toolbar.setTitleTextColor(resources.getColor(android.R.color.white, null))
        toolbar.setNavigationOnClickListener {
            finish()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }
    }

    private fun configurarBottomNavigation() {
        val bottomNavigation = findViewById<BottomNavigationView>(R.id.bottomNavigation)
        bottomNavigation.selectedItemId = R.id.nav_reportes

        bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_mapa -> {
                    startActivity(Intent(this, MenuActivity::class.java))
                    finish()
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                    true
                }
                R.id.nav_reportes -> true
                R.id.nav_perfil -> {
                    startActivity(Intent(this, PerfilActivity::class.java))
                    finish()
                    overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                    true
                }
                else -> false
            }
        }
    }

    private fun cargarReportes() {

        // ✔ Obtener nombre del usuario guardado cuando inició sesión
        val prefs = getSharedPreferences("UserSession", MODE_PRIVATE)
        val nombreUsuario = prefs.getString("nombre", "") ?: ""

        if (nombreUsuario.isEmpty()) {
            recyclerView.visibility = View.GONE
            layoutSinReportes.visibility = View.VISIBLE
            tvTotalReportes.text = "0"
            tvReportesRecientes.text = "0"
            return
        }

        val url = "https://www.inkadroid.com/alertaya/api/get_reportes.php"

        Thread {
            try {
                val connection = java.net.URL(url).openConnection() as java.net.HttpURLConnection
                connection.requestMethod = "GET"

                val response = connection.inputStream.bufferedReader().use { it.readText() }
                val jsonObject = org.json.JSONObject(response)

                runOnUiThread {
                    if (jsonObject.getString("status") == "success") {

                        val dataArray = jsonObject.getJSONArray("data")
                        val listaReportes = mutableListOf<Reporte>()

                        for (i in 0 until dataArray.length()) {
                            val obj = dataArray.getJSONObject(i)

                            // 🔥 FILTRO AQUÍ POR USUARIO (SIN TOCAR EL SERVIDOR)
                            if (obj.getString("usuario") == nombreUsuario) {

                                listaReportes.add(
                                    Reporte(
                                        id = obj.getInt("id"),
                                        titulo = obj.getString("titulo"),
                                        descripcion = obj.getString("descripcion"),
                                        tipo = obj.getString("tipo"),
                                        direccion = obj.getString("direccion"),
                                        latitud = obj.optDouble("latitud"),
                                        longitud = obj.optDouble("longitud"),
                                        foto = obj.optString("foto"),
                                        fecha = obj.getString("fecha"),
                                        estado = obj.optString("estado").ifBlank { "Pendiente" }
                                    )
                                )
                            }
                        }

                        if (listaReportes.isEmpty()) {
                            recyclerView.visibility = View.GONE
                            layoutSinReportes.visibility = View.VISIBLE
                            tvTotalReportes.text = "0"
                            tvReportesRecientes.text = "0"
                        } else {
                            recyclerView.visibility = View.VISIBLE
                            layoutSinReportes.visibility = View.GONE

                            recyclerView.layoutManager = LinearLayoutManager(this)
                            recyclerView.adapter = ReportesAdapter(listaReportes) { reporte ->
                                abrirDetalleReporte(reporte)
                            }

                            actualizarEstadisticas(listaReportes)
                        }

                    } else {
                        recyclerView.visibility = View.GONE
                        layoutSinReportes.visibility = View.VISIBLE
                    }
                }

            } catch (e: Exception) {
                e.printStackTrace()
                runOnUiThread {
                    recyclerView.visibility = View.GONE
                    layoutSinReportes.visibility = View.VISIBLE
                }
            }
        }.start()
    }

    private fun actualizarEstadisticas(reportes: List<Reporte>) {
        tvTotalReportes.text = reportes.size.toString()
        tvReportesRecientes.text = contarReportesDelMes(reportes).toString()
    }

    private fun contarReportesDelMes(reportes: List<Reporte>): Int {
        val calendar = Calendar.getInstance()
        val mesActual = calendar.get(Calendar.MONTH)
        val anioActual = calendar.get(Calendar.YEAR)

        return reportes.count { reporte ->
            try {
                val fecha = reporte.fecha ?: return@count false
                val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                val fechaReporte = sdf.parse(fecha) ?: return@count false

                calendar.time = fechaReporte
                val mesReporte = calendar.get(Calendar.MONTH)
                val anioReporte = calendar.get(Calendar.YEAR)

                mesReporte == mesActual && anioReporte == anioActual
            } catch (e: Exception) {
                false
            }
        }
    }

    private fun abrirDetalleReporte(reporte: Reporte) {
        val intent = Intent(this, DetalleReportesActivity::class.java).apply {
            putExtra("titulo", reporte.titulo)
            putExtra("descripcion", reporte.descripcion)
            putExtra("tipo", reporte.tipo)
            putExtra("direccion", reporte.direccion)
            putExtra("latitud", reporte.latitud)
            putExtra("longitud", reporte.longitud)
            putExtra("fecha", reporte.fecha)
            putExtra("foto", reporte.foto)
            putExtra("estado", reporte.estado)
        }
        startActivity(intent)
        overridePendingTransition(android.R.anim.slide_in_left, android.R.anim.slide_out_right)
    }

    override fun onResume() {
        super.onResume()
        cargarReportes()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        super.onBackPressed()
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }
}
