package com.example.appalertaya

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import org.json.JSONObject

class RegistroActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registro)

        val edtNombre = findViewById<EditText>(R.id.edtNombre)
        val edtCorreo = findViewById<EditText>(R.id.edtCorreo)
        val edtTelefono = findViewById<EditText>(R.id.edtTelefono)
        val edtContrasena = findViewById<EditText>(R.id.edtContrasena)
        val edtConfirmarContrasena = findViewById<EditText>(R.id.edtConfirmarContrasena)
        val btnRegistrar = findViewById<Button>(R.id.btnRegistrar)
        val btnIrLogin = findViewById<Button>(R.id.btnIrLogin)

        btnRegistrar.setOnClickListener {
            val nombre = edtNombre.text.toString().trim()
            val correo = edtCorreo.text.toString().trim()
            val telefono = edtTelefono.text.toString().trim()
            val contrasena = edtContrasena.text.toString().trim()
            val confirmarContrasena = edtConfirmarContrasena.text.toString().trim()

            when {
                nombre.isEmpty() -> mostrarToastError("Ingresa tu nombre completo")
                correo.isEmpty() -> mostrarToastError("Ingresa tu correo electrónico")
                !Patterns.EMAIL_ADDRESS.matcher(correo).matches() -> mostrarToastError("El formato del correo no es válido")
                telefono.isEmpty() -> mostrarToastError("Ingresa tu número de teléfono")
                telefono.length < 9 -> mostrarToastError("El teléfono debe tener al menos 9 dígitos")
                contrasena.isEmpty() -> mostrarToastError("Crea una contraseña")
                contrasena.length < 6 -> mostrarToastError("La contraseña debe tener al menos 6 caracteres")
                confirmarContrasena.isEmpty() -> mostrarToastError("Confirma tu contraseña")
                contrasena != confirmarContrasena -> mostrarDialogoContrasenasDiferentes()
                else -> registrarUsuarioEnServidor(nombre, correo, telefono, contrasena)
            }
        }

        btnIrLogin.setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }

    private fun registrarUsuarioEnServidor(nombre: String, correo: String, telefono: String, contrasena: String) {
        val url = "https://www.inkadroid.com/alertaya/api/register_user.php"

        val stringRequest = object : StringRequest(
            Request.Method.POST, url,
            { response ->
                try {
                    val jsonResponse = JSONObject(response)
                    val status = jsonResponse.getString("status")

                    if (status == "success") {
                        // ✅ Guardar datos en SharedPreferences automáticamente
                        val prefs = getSharedPreferences("UserSession", Context.MODE_PRIVATE)
                        prefs.edit()
                            .putString("nombre", nombre)
                            .putString("correo", correo)
                            .putString("telefono", telefono)
                            .apply()

                        mostrarDialogoRegistroExitoso(nombre, correo)
                    } else {
                        val message = jsonResponse.optString("message", "Error desconocido")
                        mostrarToastError(message)
                    }

                } catch (e: Exception) {
                    e.printStackTrace()
                    mostrarToastError("Error al procesar la respuesta del servidor")
                }
            },
            { error ->
                error.printStackTrace()
                mostrarToastError("Error de conexión con el servidor")
            }
        ) {
            override fun getParams(): MutableMap<String, String> {
                val params = HashMap<String, String>()
                params["nombre"] = nombre
                params["correo"] = correo
                params["telefono"] = telefono
                params["contrasena"] = contrasena
                return params
            }
        }

        stringRequest.retryPolicy = com.android.volley.DefaultRetryPolicy(
            10000,
            com.android.volley.DefaultRetryPolicy.DEFAULT_MAX_RETRIES,
            com.android.volley.DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
        )

        Volley.newRequestQueue(this).add(stringRequest)
    }

    private fun mostrarToastError(mensaje: String) {
        Toast.makeText(this, "⚠️ $mensaje", Toast.LENGTH_SHORT).apply {
            setGravity(Gravity.TOP or Gravity.CENTER_HORIZONTAL, 0, 100)
        }.show()
    }

    private fun mostrarToastExito(mensaje: String) {
        Toast.makeText(this, "✅ $mensaje", Toast.LENGTH_LONG).apply {
            setGravity(Gravity.TOP or Gravity.CENTER_HORIZONTAL, 0, 100)
        }.show()
    }

    private fun mostrarDialogoRegistroExitoso(nombre: String, correo: String) {
        MaterialAlertDialogBuilder(this)
            .setTitle("🎉 ¡Registro exitoso!")
            .setMessage("¡Bienvenido, $nombre!\n\nSe ha enviado un correo de verificación a:\n$correo")
            .setPositiveButton("Continuar") { dialog, _ ->
                dialog.dismiss()
                mostrarToastExito("Registro completado")

                startActivity(Intent(this, MenuActivity::class.java))
                finish()
            }
            .setCancelable(false)
            .show()
    }

    private fun mostrarDialogoContrasenasDiferentes() {
        MaterialAlertDialogBuilder(this)
            .setTitle("🔒 Las contraseñas no coinciden")
            .setMessage("Por favor asegúrate de que ambas contraseñas sean idénticas.")
            .setPositiveButton("Entendido") { dialog, _ -> dialog.dismiss() }
            .show()
    }
}
